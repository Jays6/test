const { MessageActionRow, MessageEmbed, MessageButton } = require("discord.js");
const UserIdModel = require("../../database/models/UserId");
const CharModel = require("../../database/models/userData");

module.exports.run = async (client, interaction) => {
  if (!interaction.isButton()) return;

  try {
    const userIdDoc = await UserIdModel.findOne({
      messageId: interaction.message.id,
    });

    if (!userIdDoc) {
      throw new Error("User ID document not found.");
    }

    const user = await interaction.guild.members.fetch(userIdDoc.user_id);

    if (interaction.customId === "acceptButton") {
      // Add the user to the guild and give them a role
      const c1role = interaction.guild.roles.cache.get("1202577174423539722");
      const c2role = interaction.guild.roles.cache.get("1202577192370962442");
      const c3role = interaction.guild.roles.cache.get("1202577206442856468");
      if (userIdDoc?.character == "character-1") {
        await user?.roles?.add(c1role);
      } else if (userIdDoc?.character == "character-2") {
        await user?.roles?.add(c2role);
      } else if (userIdDoc?.character == "character-3") {
        await user?.roles?.add(c3role);
      }

      await user.send(`Hello Dear **${user.user.username}** ,\nCongratulations , your application has been accepted in ${interaction.guild.name}.
      `);

      let accepted = new MessageEmbed()
        .setAuthor({
          name: `Application of ${user.user.username} has been accepted`,
        })
        .setDescription(`Accepted By ${interaction.user}`)
        .setColor("#00FF00")
        .setThumbnail(
          `https://cdn.discordapp.com/attachments/1196800584787955732/1198587496200671282/IMG_4634.png?ex=65bf7297&is=65acfd97&hm=ec2e3165907892f57ded8a7104430e20397dbb92706e45c1a0a4fb7798abadfd&`
        );
      interaction.update({ embeds: [accepted], components: [] });
    } else if (interaction.customId === "declineButton") {
      try {
        await CharModel.deleteOne({
          userID: user.user.id,
        });
        await UserIdModel.deleteOne({
          user_id: user.user.id,
        });
        await user.send(
          `Hello Dear **${user.user.username}**,\nUnfortunately, your application has been declined in ${interaction.guild.name}.`
        );
        let declined = new MessageEmbed()
          .setAuthor(`Application of ${user.user.username} has been declined`)
          .setDescription(`Declined By ${interaction.user.tag}`)
          .setColor("#FF0000")
          .setThumbnail(
            "https://cdn.discordapp.com/attachments/1196800584787955732/1198587496200671282/IMG_4634.png?ex=65bf7297&is=65acfd97&hm=ec2e3165907892f57ded8a7104430e20397dbb92706e45c1a0a4fb7798abadfd&"
          );
        await interaction.editReply({ embeds: [declined], components: [] });
      } catch (error) {
        console.error(error); // Log any errors
      }
    }
  } catch (error) {
    console.error("Error sending DM:", error);
    interaction.reply(
      "There was an error sending a direct message. Please ensure your DMs are open."
    );
  }
};
