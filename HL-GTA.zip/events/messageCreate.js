const { MessageEmbed } = require("discord.js");
const config = require("../config.js");

module.exports.run = async (client, message) => {
  let prefix = config.prefix;
  if (message.author.bot) return;

  if (!message.content.startsWith(prefix)) return;

  const args = message.content.slice(prefix.length).trim().split(/ +/g);
  const cmd = args.shift().toLowerCase();
  if (cmd.length === 0) return;
  let command = client.preCommands.get(cmd);
  if (!command) command = client.preCommands.get(client.aliases.get(cmd));
  if (!command) return;

  if (command.category == "dev" && !config.devs.includes(message.author.id)) {
    let embed = new MessageEmbed()
      .setColor("#ff0000")
      .setDescription(
        ` - only ${"<@" + config.devs.join("> , ")} can use this command`
      );

    message.channel.send({ embeds: [embed] });
    return;
  }

  await command.execute(client, message, args);
};
