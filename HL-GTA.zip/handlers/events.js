const { readdirSync, lstatSync } = require("fs");
const path = require("path");
const ascii = require("ascii-table");

let table = new ascii("Events");
table.setHeading("Event Name", "Loaded Status");

module.exports = client => {
  loadEvents(client, path.join(__dirname, "../events"));
};

function loadEvents(client, directory) {
  const files = readdirSync(directory);
  for (let file of files) {
    try {
      const filePath = path.join(directory, file);
      const isDirectory = lstatSync(filePath).isDirectory();

      if (isDirectory) {
        loadEvents(client, filePath);
      } else if (file.endsWith(".js")) {
        const pull = require(filePath);
        loadEvent(client, pull, filePath);
      } else {
        table.addRow(file, `❌ -> Invalid file format.`);
      }
    } catch (err) {
      console.log("");
      console.log(err);
      table.addRow(file, `❌ -> Error`);
    }
  }
}

function loadEvent(client, pull, filePath) {
  if (pull.event && typeof pull.event !== "string") {
    table.addRow(filePath, `❌ -> Property event should be a string.`);
    return;
  }

  const fileName = path.basename(filePath);
  const eventName = pull.event || path.parse(fileName).name.split(".")[0];

  client.on(eventName, (...args) => pull.run(client, ...args));
  table.addRow(fileName, "✅");
}
