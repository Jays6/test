const { MessageEmbed, MessageAttachment } = require("discord.js");

const { REST } = require("@discordjs/rest");
const { Routes } = require("discord-api-types/v9");
const colors = require("colors");

module.exports.run = async (client) => {
  client.user.setActivity("+char", {
    type: "STREAMING",
    url: "https://www.twitch.tv/A&M",
  });
  console.log(
    `${colors.blue(`[ ${client.user.tag} ] ::`)} ${colors.green("ONLINE")}`
  );

  const commands = client.commands.toJSON();

  let arr = [];
  for (let i = 0; i < commands.length; i++) {
    const command = require(`../commands/${commands[i].category}/${commands[i].name}`);
    arr.push(command.slashCmdData);
  }

  const rest = new REST({ version: "9" }).setToken(process.env.TOKEN);

  (async () => {
    try {
      await rest.put(Routes.applicationCommands(client.user.id), { body: arr });
      console.log(colors.blue("[ Commands ]::") + colors.green(" Pushed"));
    } catch (error) {
      console.error(colors.red(error));
    }
  })();
};
