module.exports = {
  devs: ["423445639574323201", "733370648822284299"],
  prefix: "+",
  coderRole: "1143147727304261694",
  actionlimit: "3",
  actionlogId: "1177972625218207794",
};
