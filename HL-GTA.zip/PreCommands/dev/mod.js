const {
  MessageActionRow,
  MessageEmbed,
  MessageButton,
  MessageSelectMenu,
  MessageAttachment,
} = require("discord.js");
const path = require("path");
module.exports = {
  name: "char",
  description: "charachter chooser",
  category: "dev",
  async execute(client, message, args) {
    message.delete();
    const characterchoose = new MessageEmbed()
      .setAuthor({ name: "Charachter Chooser" })
      .setColor("#be8212")
      .setDescription(`Choose Your Charachter 🌐`)
      .setImage("https://i8.ae/ktZgW");

    const selectMenu = new MessageSelectMenu()
      .setCustomId("select")
      .setPlaceholder("اختر شخصية")
      .addOptions([
        {
          label: "👥 الشخصية الاولى",
          description: "لتقوم بأختيار الكركتر الاول",
          value: "character-1",
        },
        {
          label: "👥 الشخصية الثانية",
          description: "لتقوم بأختيار الكركتر الثاني",

          value: "character-2",
        },
        {
          label: "👥 الشخصية الثالثة",
          description: "لتقوم بأختيار الكركتر الثالث",
          value: "character-3",
        },
      ]);

    const row = new MessageActionRow().addComponents(selectMenu);

    await message.channel.send({
      content: "||@everyone||",
      embeds: [characterchoose],
      components: [row],
    });
  },
};
