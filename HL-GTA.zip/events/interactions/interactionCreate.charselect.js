const {
  MessageActionRow,
  Modal,
  TextInputComponent,
  MessageEmbed,
  MessageButton,
} = require("discord.js");
const UserIdModel = require("../../database/models/UserId");
const CharModel = require("../../database/models/userData");

module.exports.run = async (client, interaction) => {
  if (!interaction.isSelectMenu()) return;

  const selectedValue = interaction.values[0];
  const characterData = await CharModel.findOne({
    userID: interaction.user.id,
  });

  let charfind = characterData?.characters?.find(
    (c) => c.character == selectedValue
  );

  if (characterData?.limit >= 3) {
    interaction.reply({
      content: "لقد وصلت الحد الاقصى للتقديمات",
      ephemeral: true,
    });
  }

  characterData?.characters?.forEach(async (t) => {
    if (t?.character?.includes(selectedValue)) {
      return interaction.reply({
        content: "انت تمتلك هذه الشخصية بالفعل",
        ephemeral: true,
      });
    }
  });

  let logChannel = "1200412259239870536";
  if (
    selectedValue === "character-1" ||
    selectedValue === "character-2" ||
    selectedValue === "character-3"
  ) {
    const fields = {
      username: new TextInputComponent()
        .setCustomId(`usrName`)
        .setLabel(`الاسم`)
        .setStyle(`SHORT`)
        .setMaxLength(18)
        .setRequired(true),
      userage: new TextInputComponent()
        .setCustomId(`usrAge`)
        .setLabel(`العمر`)
        .setStyle(`SHORT`)
        .setMaxLength(2)
        .setMinLength(1)
        .setRequired(true),
      birthday: new TextInputComponent()
        .setCustomId(`usrBirth`)
        .setLabel(`تاريخ الميلاد`)
        .setStyle(`SHORT`)
        .setMaxLength(15)
        .setMinLength(5)
        .setRequired(true),
      bornAt: new TextInputComponent()
        .setCustomId(`usrBorn`)
        .setLabel(`مكان الميلاد`)
        .setPlaceholder(`الاماكن المتوفرة : بوليتو , ساندي شور , لوس سانتوس`)
        .setStyle(`SHORT`)
        .setMaxLength(15)
        .setMinLength(6)
        .setRequired(true),
      avatar: new TextInputComponent()
        .setCustomId(`usrAvatar`)
        .setLabel(`الصورة الشخصية`)
        .setStyle(`PARAGRAPH`)
        .setMaxLength(400)
        .setMinLength(10)
        .setRequired(true),
    };

    const modal = new Modal()
      .setCustomId(`characterModal`)
      .setTitle(`Character Information`)
      .addComponents(
        new MessageActionRow().addComponents(fields.username),
        new MessageActionRow().addComponents(fields.userage),
        new MessageActionRow().addComponents(fields.birthday),
        new MessageActionRow().addComponents(fields.bornAt),
        new MessageActionRow().addComponents(fields.avatar)
      );

    await interaction.showModal(modal);

    const modalSubmit = await interaction
      .awaitModalSubmit({
        time: 0,
        filter: (i) => i.user.id === interaction.user.id,
      })
      .catch((err) => {});

    const log = interaction.guild.channels.cache.get(logChannel);

    if (modalSubmit) {
      let username = modalSubmit.fields.getTextInputValue("usrName");
      let userage = modalSubmit.fields.getTextInputValue("usrAge");
      let birthday = modalSubmit.fields.getTextInputValue("usrBirth");
      let bornAt = modalSubmit.fields.getTextInputValue("usrBorn");
      let avatar = modalSubmit.fields.getTextInputValue("usrAvatar");

      if (!avatar.startsWith("https://")) {
        return modalSubmit.reply({
          content: "يجب ان تكون الصورة عن طريق رابط ",
          ephemeral: true,
        });
      }

      if (
        bornAt !== "لوس سانتوس" &&
        bornAt !== "بوليتو" &&
        bornAt !== "ساندي شور"
      ) {
        return modalSubmit.reply({
          content: "الاماكن المتوفرة: بوليتو, ساندي شور, لوس سانتوس",
          ephemeral: true,
        });
      }

      const acceptButton = new MessageButton()
        .setCustomId("acceptButton")
        .setLabel("قبول")
        .setStyle("SUCCESS"); // Green color for accept

      const declineButton = new MessageButton()
        .setCustomId("declineButton")
        .setLabel("رفض")
        .setStyle("DANGER"); // Red color for decline

      const row = new MessageActionRow().addComponents(
        acceptButton,
        declineButton
      );

      let application = new MessageEmbed()
        .setAuthor({
          name: `طلب جديد من ${interaction.user.username}`,
        })
        .addFields(
          {
            name: `الاسم :`,
            value: `${username}`,
            inline: false,
          },
          {
            name: `العمر :`,
            value: `${userage}`,
            inline: false,
          },
          {
            name: `تاريخ الميلاد :`,
            value: `${birthday}`,
            inline: false,
          },
          {
            name: `مكان الولادة :`,
            value: `${bornAt}`,
            inline: false,
          }
        )
        .setImage(avatar)
        .setThumbnail(
          `https://cdn.discordapp.com/attachments/1196800584787955732/1198587496200671282/IMG_4634.png?ex=65bf7297&is=65acfd97&hm=ec2e3165907892f57ded8a7104430e20397dbb92706e45c1a0a4fb7798abadfd&`
        )
        .setFooter({ text: `${selectedValue}` });
      log
        .send({ embeds: [application], components: [row] })
        .then(async (msg) => {
          UserIdModel.create({
            character: selectedValue,
            messageId: msg.id,
            user_id: interaction.user.id,
          });
          let limit = 1;
          if (characterData) {
            limit = characterData.limit + 1;
          }

          if (!characterData) {
            await new CharModel({
              userID: interaction.user.id,
              limit: limit,
              characters: [
                {
                  character: selectedValue,
                  usrName: username,
                  userage: userage,
                  birthday: birthday,
                  bornAt: bornAt,
                  avatar: avatar,
                },
              ],
            }).save();
          }
          if (characterData) {
            characterData.characters.push({
              character: selectedValue,
              usrName: username,
              userage: userage,
              birthday: birthday,
              bornAt: bornAt,
              avatar: avatar,
            });
            characterData.limit = limit;
            await characterData.save();
          }
        });

      modalSubmit.reply({
        content: `تم ارسال طلبك الى المسؤولين , الرجاء منك انتظار الرد`,
        ephemeral: true,
      });
    }
  }
};
