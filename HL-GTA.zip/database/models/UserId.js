const { Schema, model } = require("mongoose");

const userIdSchema = new Schema({
  character: { type: String, required: true },
  messageId: { type: String, required: true, unique: true },
  user_id: { type: String, required: true },
});

module.exports = model("UserId", userIdSchema);
