const { MessageEmbed } = require("discord.js");
const config = require("../../config");

// Map to track deletion timestamps for each user
const deletionTracker = new Map();

module.exports.run = async (client, role) => {
  const logChannel = role.guild.channels.cache.get(config.actionlogId);
  if (!logChannel) return;

  // Fetch audit logs
  const fetchedLogs = await role.guild.fetchAuditLogs({
    limit: 1,
    type: "ROLE_DELETE",
  });

  const channelDeleteLog = fetchedLogs.entries.first();
  if (!channelDeleteLog) return;

  const { executor } = channelDeleteLog;
  const now = Date.now();
  const userId = executor.id;

  // Track deletion timestamps for each user
  if (!deletionTracker.has(userId)) {
    deletionTracker.set(userId, new Set());
  }

  const userDeletionTimestamps = deletionTracker.get(userId);
  userDeletionTimestamps.add(now);

  // Remove timestamps older than 10 seconds
  for (const timestamp of userDeletionTimestamps) {
    if (now - timestamp > 10000) {
      userDeletionTimestamps.delete(timestamp);
    }
  }

  // Check if the user deleted more than 3 channels in 10 seconds
  if (userDeletionTimestamps.size == 3) {
    const roleIdToRemove = "1176602351176519750"; // Replace with the role ID you want to remove

    // Get the member
    const member = role.guild.members.cache.get(userId);

    // Remove the role
    if (member && member.roles.cache.has(roleIdToRemove)) {
      member.roles.remove(roleIdToRemove).catch((error) => {
        console.error("Error removing role:", error);
      });
    }
  }

  const embed = new MessageEmbed()
    .setTitle(":warning: تحذير حذف رتبة :warning: ")
    .setDescription(`اسم الرتبة: ${role.name}`)
    .addFields(
      {
        name: "تم الحذف من قبل",
        value: `<@${executor.id}>`,
        inline: true,
      },
      {
        name: "في تمام الساعة",
        value: `<t:${Math.floor(now / 1000)}:F>`,
      },
      {
        name: "محاولات",
        value: `${userDeletionTimestamps.size}`,
      }
    )
    .setAuthor({
      name: executor.username,
      iconURL: executor.displayAvatarURL(),
    })
    .setFooter({ text: role.guild.name, iconURL: role.guild.iconURL() })
    .setTimestamp();

  if (userDeletionTimestamps.size == 3) {
    embed.addFields({
      name: "لقد تم اتخاذ الاجراءات اللازمة",
      value: `لقد تم ازالة الرتبة من ${executor} بسبب تخطيه للحد الاقصى`,
    });
  }

  logChannel.send({ embeds: [embed] });
};
