const UserIdModel = require("../../database/models/UserId");

module.exports = {
  name: "deletedb",
  description: "deletedb",
  category: "dev",
  async execute(client, message, args) {
    if (!message.member.permissions.has("ADMINSTARTOR")) return;
    await UserIdModel.deleteMany({});
    message.react("✅");
  },
};
