
const mongoose = require("mongoose")
const colors = require("colors")
mongoose.set("strictQuery" , false)
mongoose.connect(process.env.MONGO_URL)


mongoose.connection.on("open", () => {
console.log(colors.blue("[ Database ]::") + colors.green(" Connected"))
})

mongoose.connection.on("error", err => {
console.error(`${colors.red("[ Database ]:: Error:")} \n ${err}`)
})