const { MessageEmbed } = require("discord.js");
const config = require("../../config");
const deletionTracker = new Map();

module.exports.run = async (client, member) => {
  const logChannel = member.guild.channels.cache.get(config.actionlogId);
  if (!logChannel) return;

  // Fetch audit logs
  const fetchedLogs = await member.guild.fetchAuditLogs({
    type: "MEMBER_KICK",
    limit: 1,
  });

  const kickLog = fetchedLogs.entries.first();
  if (!kickLog) return;
  const { executor, target } = kickLog;
  const now = Date.now();
  const userId = executor.id;
  const user = member.guild.members.cache.get(userId);

  // Track deletion timestamps for each user
  if (!deletionTracker.has(userId)) {
    deletionTracker.set(userId, new Set());
  }

  const userDeletionTimestamps = deletionTracker.get(userId);
  userDeletionTimestamps.add(now);

  // Remove timestamps older than 10 seconds
  for (const timestamp of userDeletionTimestamps) {
    if (now - timestamp > 10000) {
      userDeletionTimestamps.delete(timestamp);
    }
  }

  // Check if the user deleted more than 3 channels in 10 seconds
  if (userDeletionTimestamps.size == 3) {
    const roleIdToRemove = "1176602351176519750"; // Replace with the role ID you want to remove

    if (user && user.roles.cache.has(roleIdToRemove)) {
      user.roles.remove(roleIdToRemove).catch((error) => {
        console.error("Error removing role:", error);
      });
    }
  }

  const embed = new MessageEmbed()
    .setTitle(":warning: تحذير طرد شخص :warning: ")
    .addFields(
      {
        name: "العضو",
        value: `${target}`,
        inline: true,
      },
      {
        name: "تم الطرد من قبل",
        value: `<@${executor.id}>`,
        inline: true,
      },
      {
        name: "في تمام الساعة",
        value: `<t:${Math.floor(now / 1000)}:F>`,
      },
      {
        name: "محاولات",
        value: `${userDeletionTimestamps.size}`,
      }
    )
    .setAuthor({
      name: executor.username,
      iconURL: executor.displayAvatarURL(),
    })
    .setFooter({ text: member.guild.name, iconURL: member.guild.iconURL() })
    .setTimestamp();

  if (userDeletionTimestamps.size == 3) {
    embed.addFields({
      name: "لقد تم اتخاذ الاجراءات اللازمة",
      value: `لقد تم ازالة الرتبة من ${executor} بسبب تخطيه للحد الاقصى`,
    });
  }

  logChannel.send({ embeds: [embed] });
};
