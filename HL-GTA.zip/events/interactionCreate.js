module.exports.run = async (client, interaction) => {
  if (interaction.user.bot) return;

  if (interaction.isCommand()) {
    if (!client.commands.has(interaction.commandName)) return;

    let command = client.commands.get(interaction.commandName);
    if (!command) return;

    if (command.needDefer == true) {
      await interaction.deferReply();
    }

    await client.commands
      .get(interaction.commandName)
      .execute(client, interaction);
  }

};
