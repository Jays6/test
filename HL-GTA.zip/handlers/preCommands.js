const { readdirSync } = require('fs'),
    ascii = require('ascii-table'),
    table = new ascii('PreCommands');
table.setHeading('Command Name', 'Loaded Status');

module.exports = (client) => {
    readdirSync('./PreCommands/').forEach(dir => {
        const commands = readdirSync(`./PreCommands/${dir}/`).filter(file => file.endsWith('.js'));
        for (let file of commands) {
            let pull = require(`../PreCommands/${dir}/${file}`);
            if (pull.name) {
                client.preCommands.set(pull.name, pull);
                table.addRow(pull.name, '✅');
            } else {
                table.addRow(pull.name, `❌  -> missing a help.name, or help.name is not a string.`);
                continue;
            }
            if (pull.aliases && Array.isArray(pull.aliases)) pull.aliases.forEach(alias => client.aliases.set(alias, pull.name));
        }
    });
};