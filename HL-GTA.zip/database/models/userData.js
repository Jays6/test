const { Schema, model } = require("mongoose");

const userDataSchema = new Schema({
  userID: {
    type: String,
    unique: true,
  },
  characters: {
    type: Array,
    default: [],
  },
  limit: { type: Number, default: 1 },
});

const UserData = model("UserData", userDataSchema);

module.exports = UserData;
